/**
 * @jest-environment jsdom
 */

global.HTTP_VERSION = 1;

require('./main');
