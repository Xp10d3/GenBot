module.exports = require('./src/generate');
